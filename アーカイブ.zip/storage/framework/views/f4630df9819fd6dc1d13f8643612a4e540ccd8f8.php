<?php $__env->startSection('content'); ?>
<div class="w-75 m-auto">
  <div class="w-100">
    <p><?php echo e($calendar->getTitle()); ?></p>
    <p><?php echo $calendar->render(); ?></p>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/oobayashitakeshishi/PJ-G-obayashi/PJ-G-obayashi/AtlasManagementSystem-master/resources/views/authenticated/calendar/admin/calendar.blade.php ENDPATH**/ ?>