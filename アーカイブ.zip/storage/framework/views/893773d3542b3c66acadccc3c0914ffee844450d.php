<?php $__env->startSection('content'); ?>
<div class="w-100 vh-100 d-flex" style="align-items:center; justify-content:center;">
  <div class="w-100 vh-100 border p-5">
    <?php echo $calendar->render(); ?>

    <div class="adjust-table-btn m-auto text-right">
      <input type="submit" class="btn btn-primary" value="登録" form="reserveSetting" onclick="return confirm('登録してよろしいですか？')">
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/oobayashitakeshishi/PJ-G-obayashi/PJ-G-obayashi/AtlasManagementSystem-master/resources/views/authenticated/calendar/admin/reserve_setting.blade.php ENDPATH**/ ?>