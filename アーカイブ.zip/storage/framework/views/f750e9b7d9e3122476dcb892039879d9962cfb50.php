<?php $__env->startSection('content'); ?>
<div class="vh-100 border">
  <div class="top_area w-75 m-auto pt-5">
    <p>マイページ</p>
    <div class="user_status p-3">
      <p>名前：<span><?php echo e(Auth::user()->over_name); ?></span><span class="ml-1"><?php echo e(Auth::user()->under_name); ?></span></p>
      <p>カナ：<span><?php echo e(Auth::user()->over_name_kana); ?></span><span class="ml-1"><?php echo e(Auth::user()->under_name_kana); ?></span></p>
      <p>性別：<?php if(Auth::user()->sex == 1): ?><span>男</span><?php else: ?><span>女</span><?php endif; ?></p>
      <p>生年月日：<span><?php echo e(Auth::user()->birth_day); ?></span></p>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/oobayashitakeshishi/PJ-G-obayashi/PJ-G-obayashi/AtlasManagementSystem-master/resources/views/authenticated/top/top.blade.php ENDPATH**/ ?>