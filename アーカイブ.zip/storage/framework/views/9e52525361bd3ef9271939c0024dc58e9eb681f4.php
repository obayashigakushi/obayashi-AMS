<?php $__env->startSection('content'); ?>
<div class="vh-100 pt-5" style="background:#ECF1F6;">
  <div class="border w-75 m-auto pt-5 pb-5" style="border-radius:5px; background:#FFF;">
    <div class="w-75 m-auto border" style="border-radius:5px;">

      <p class="text-center"><?php echo e($calendar->getTitle()); ?></p>
      <div class="">
        <?php echo $calendar->render(); ?>

      </div>
    </div>
    <div class="text-right w-75 m-auto">
      <input type="submit" class="btn btn-primary" value="予約する" form="reserveParts">
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/oobayashitakeshishi/PJ-G-obayashi/PJ-G-obayashi/AtlasManagementSystem-master/resources/views/authenticated/calendar/general/calendar.blade.php ENDPATH**/ ?>